function vermas(uno,boton1){
           if(document.getElementById('uno').style.display=='block') {
    document.getElementById('uno').style.display = 'none';
    document.getElementById('boton1').innerHTML = 'Leer MÃ¡s';
    }
    else {
        document.getElementById('uno').style.display = 'block';
        document.getElementById('boton1').innerHTML = 'Leer Menos';
        
    
    }
    }



function vermass(dos,boton2){
           if(document.getElementById('dos').style.display=='block') {
    document.getElementById('dos').style.display = 'none';
    document.getElementById('boton2').innerHTML = 'Leer MÃ¡s';
    }
    else {
        document.getElementById('dos').style.display = 'block';
        document.getElementById('boton2').innerHTML = 'Leer Menos';
        
    
    }
    }

function vermas3(tres,boton3){
           if(document.getElementById('tres').style.display=='block') {
    document.getElementById('tres').style.display = 'none';
    document.getElementById('boton3').innerHTML = 'Leer MÃ¡s';
    }
    else {
        document.getElementById('tres').style.display = 'block';
        document.getElementById('boton3').innerHTML = 'Leer Menos';
        
    
    }
    }

function vermas4(cuatro,boton4){
           if(document.getElementById('cuatro').style.display=='block') {
    document.getElementById('cuatro').style.display = 'none';
    document.getElementById('boton4').innerHTML = 'Leer MÃ¡s';
    }
    else {
        document.getElementById('cuatro').style.display = 'block';
        document.getElementById('boton4').innerHTML = 'Leer Menos';
        
    
    }
    }

function vermas5(cinco,boton5){
           if(document.getElementById('cinco').style.display=='block') {
    document.getElementById('cinco').style.display = 'none';
    document.getElementById('boton5').innerHTML = 'Leer MÃ¡s';
    }
    else {
        document.getElementById('cinco').style.display = 'block';
        document.getElementById('boton5').innerHTML = 'Leer Menos';
        
    
    }
    }

    function vermas6(seis,boton6){
           if(document.getElementById('seis').style.display=='block') {
    document.getElementById('seis').style.display = 'none';
    document.getElementById('boton6').innerHTML = 'Leer MÃ¡s';
    }
    else {
        document.getElementById('seis').style.display = 'block';
        document.getElementById('boton6').innerHTML = 'Leer Menos';
        
    
    }
    }
    

function vermas7(siete,boton7){
           if(document.getElementById('siete').style.display=='block') {
    document.getElementById('siete').style.display = 'none';
    document.getElementById('boton7').innerHTML = 'Leer MÃ¡s';
    }
    else {
        document.getElementById('siete').style.display = 'block';
        document.getElementById('boton7').innerHTML = 'Leer Menos';
        
    
    }
    }


function vermas8(ocho,boton8){
           if(document.getElementById('ocho').style.display=='block') {
    document.getElementById('ocho').style.display = 'none';
    document.getElementById('boton8').innerHTML = 'Leer MÃ¡s';
    }
    else {
        document.getElementById('ocho').style.display = 'block';
        document.getElementById('boton8').innerHTML = 'Leer Menos';
        
    
    }
    }


function vermas9(nueve,boton9){
           if(document.getElementById('nueve').style.display=='block') {
    document.getElementById('nueve').style.display = 'none';
    document.getElementById('boton9').innerHTML = 'Leer MÃ¡s';
    }
    else {
        document.getElementById('nueve').style.display = 'block';
        document.getElementById('boton9').innerHTML = 'Leer Menos';
        
    
    }
    }



function vermas10(diez,boton10){
           if(document.getElementById('diez').style.display=='block') {
    document.getElementById('diez').style.display = 'none';
    document.getElementById('boton10').innerHTML = 'Leer MÃ¡s';
    }
    else {
        document.getElementById('diez').style.display = 'block';
        document.getElementById('boton10').innerHTML = 'Leer Menos';
        
    
    }
    }