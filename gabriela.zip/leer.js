function vermas(uno,boton1){
           if(document.getElementById('uno').style.display=='block') {
    document.getElementById('uno').style.display = 'none';
    document.getElementById('boton1').innerHTML = 'Leer Más';
    }
    else {
        document.getElementById('uno').style.display = 'block';
        document.getElementById('boton1').innerHTML = 'Leer Menos';
        
    
    }
    }



function vermass(dos,boton2){
           if(document.getElementById('dos').style.display=='block') {
    document.getElementById('dos').style.display = 'none';
    document.getElementById('boton2').innerHTML = 'Leer Más';
    }
    else {
        document.getElementById('dos').style.display = 'block';
        document.getElementById('boton2').innerHTML = 'Leer Menos';
        
    
    }
    }

function vermas3(tres,boton3){
           if(document.getElementById('tres').style.display=='block') {
    document.getElementById('tres').style.display = 'none';
    document.getElementById('boton3').innerHTML = 'Leer Más';
    }
    else {
        document.getElementById('tres').style.display = 'block';
        document.getElementById('boton3').innerHTML = 'Leer Menos';
        
    
    }
    }

function vermas4(cuatro,boton4){
           if(document.getElementById('cuatro').style.display=='block') {
    document.getElementById('cuatro').style.display = 'none';
    document.getElementById('boton4').innerHTML = 'Leer Más';
    }
    else {
        document.getElementById('cuatro').style.display = 'block';
        document.getElementById('boton4').innerHTML = 'Leer Menos';
        
    
    }
    }

function vermas5(cinco,boton5){
           if(document.getElementById('cinco').style.display=='block') {
    document.getElementById('cinco').style.display = 'none';
    document.getElementById('boton5').innerHTML = 'Leer Más';
    }
    else {
        document.getElementById('cinco').style.display = 'block';
        document.getElementById('boton5').innerHTML = 'Leer Menos';
        
    
    }
    }
